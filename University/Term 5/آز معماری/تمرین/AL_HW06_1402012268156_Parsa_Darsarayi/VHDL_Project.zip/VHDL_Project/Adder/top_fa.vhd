library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity top_fa is
    Port ( K1 : in STD_LOGIC;
           K2 : in STD_LOGIC;
           K3 : in STD_LOGIC;
           LED1 : out STD_LOGIC;
           LED2 : out STD_LOGIC );
end top_fa;

architecture Behavioral of top_fa is
    component full_adder
        Port ( A : in STD_LOGIC;
               B : in STD_LOGIC;
               Cin: in STD_LOGIC;
               SUM: out STD_LOGIC;
               Cout: out STD_LOGIC );
    end component;

begin
    U1: full_adder port map(A=>K1, B=>K2, Cin=>K3, SUM=>LED1, Cout=>LED2);
end Behavioral;
