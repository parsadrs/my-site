library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_full_adder is
end tb_full_adder;

architecture behavior of tb_full_adder is
    signal A, B, Cin : STD_LOGIC := '0';
    signal SUM, Cout : STD_LOGIC;

    component full_adder
        Port ( A : in STD_LOGIC;
               B : in STD_LOGIC;
               Cin: in STD_LOGIC;
               SUM: out STD_LOGIC;
               Cout: out STD_LOGIC );
    end component;

begin
    DUT: full_adder port map(A, B, Cin, SUM, Cout);

    stim: process
    begin
        for i in 0 to 7 loop
            A <= std_logic'val((i/4) mod 2);
            B <= std_logic'val((i/2) mod 2);
            Cin <= std_logic'val(i mod 2);
            wait for 20 ns;
        end loop;
        wait;
    end process;
end behavior;
