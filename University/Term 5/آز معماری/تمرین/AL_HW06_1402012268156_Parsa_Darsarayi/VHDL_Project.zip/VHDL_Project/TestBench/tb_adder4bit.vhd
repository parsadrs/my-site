library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_adder4bit is
end tb_adder4bit;

architecture behavior of tb_adder4bit is
    signal A, B : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal Cin  : STD_LOGIC := '0';
    signal SUM  : STD_LOGIC_VECTOR(3 downto 0);
    signal Cout : STD_LOGIC;

    component adder4bit
        Port ( A : in STD_LOGIC_VECTOR(3 downto 0);
               B : in STD_LOGIC_VECTOR(3 downto 0);
               Cin : in STD_LOGIC;
               SUM : out STD_LOGIC_VECTOR(3 downto 0);
               Cout: out STD_LOGIC );
    end component;

begin
    DUT: adder4bit port map(A, B, Cin, SUM, Cout);

    stim: process
    begin
        A <= "0101"; B <= "0011"; Cin <= '0'; wait for 30 ns;
        A <= "1111"; B <= "0001"; Cin <= '1'; wait for 30 ns;
        A <= "1000"; B <= "1000"; Cin <= '0'; wait for 30 ns;
        A <= "1010"; B <= "0101"; Cin <= '1'; wait for 30 ns;
        wait;
    end process;

end behavior;
