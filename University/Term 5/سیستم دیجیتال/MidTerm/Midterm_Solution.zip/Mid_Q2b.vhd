-------------------------------------------------------------------------------
--
-------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.all;

entity Mid_Q2a is	
	port (
	clk,Reset , DS: in std_logic;
	X,Y,Z : in std_logic_vector(7 downto 0);
	MS : in std_logic_vector(1 downto 0);
	RA,RB : out std_logic_vector(7 downto 0) );
end Mid_Q2a;

--}} End of automatically maintained section

architecture Mid_Q2a of Mid_Q2a is 
signal RAq,RBq  :std_logic_vector(7 downto 0);
begin  
	
	process(clk , reset)
	
	begin 
		-- asynchronous reset
		if reset = '1' then
			RAq <=(others =>'0'); 
			RBq <=(others =>'0'); 
			
		elsif falling_edge(clk) then 
			if (DS ='0') then
				case MS is
					when "00"=> RAq <= RBq;
					when "01"=> RAq <= Z;
					when "10"=> RAq <= Y;
					when others=> RAq <= X;
				end case;
				RBq <= RBq;
			else
				RBq <= RAq;
				RAq <= RAq;
			end if;
		
	end process;
	RA <=RAq;
	RB <= RBq; 

end Mid_Q2a;
